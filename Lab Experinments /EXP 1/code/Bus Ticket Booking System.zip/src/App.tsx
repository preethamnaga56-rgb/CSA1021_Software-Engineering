import { useMemo, useState, type ReactNode } from "react";

type IconName =
  | "arrow"
  | "bus"
  | "calendar"
  | "check"
  | "chevron"
  | "clock"
  | "location"
  | "menu"
  | "route"
  | "search"
  | "shield"
  | "spark"
  | "swap"
  | "ticket"
  | "user"
  | "wifi"
  | "zap";

const paths: Record<IconName, ReactNode> = {
  arrow: <path d="m5 12 14 0m-5-5 5 5-5 5" />,
  bus: (
    <>
      <path d="M5 17V6.5C5 4.6 6.6 3 8.5 3h7C17.4 3 19 4.6 19 6.5V17" />
      <path d="M5 12h14M8 7h8M7 17v2m10-2v2" />
      <circle cx="8" cy="15" r=".7" fill="currentColor" />
      <circle cx="16" cy="15" r=".7" fill="currentColor" />
    </>
  ),
  calendar: (
    <>
      <rect x="3.5" y="5" width="17" height="15" rx="2.5" />
      <path d="M8 3v4m8-4v4M3.5 9.5h17" />
    </>
  ),
  check: <path d="m5 12 4 4L19 6" />,
  chevron: <path d="m9 18 6-6-6-6" />,
  clock: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5l3 2" />
    </>
  ),
  location: (
    <>
      <path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z" />
      <circle cx="12" cy="10" r="2.5" />
    </>
  ),
  menu: <path d="M4 7h16M4 12h16M4 17h16" />,
  route: (
    <>
      <circle cx="6" cy="18" r="2.5" />
      <circle cx="18" cy="6" r="2.5" />
      <path d="M8.5 18h2a2 2 0 0 0 2-2V8a2 2 0 0 1 2-2h1" />
    </>
  ),
  search: (
    <>
      <circle cx="11" cy="11" r="7" />
      <path d="m16.5 16.5 4 4" />
    </>
  ),
  shield: (
    <>
      <path d="M12 3 5 6v5c0 4.6 2.8 8.2 7 10 4.2-1.8 7-5.4 7-10V6l-7-3Z" />
      <path d="m9 12 2 2 4-5" />
    </>
  ),
  spark: <path d="m12 2 1.8 6.2L20 10l-6.2 1.8L12 18l-1.8-6.2L4 10l6.2-1.8L12 2Z" />,
  swap: <path d="m7 7 3-3m-3 3 3 3M17 17l-3 3m3-3-3-3M8 7h9M16 17H7" />,
  ticket: (
    <>
      <path d="M4 7.5A2.5 2.5 0 0 0 6.5 5h11A1.5 1.5 0 0 1 19 6.5v11a1.5 1.5 0 0 1-1.5 1.5h-11A2.5 2.5 0 0 0 4 16.5v-9Z" />
      <path d="M9 8v8m4-8v1m0 2v1m0 2v2" />
    </>
  ),
  user: (
    <>
      <circle cx="12" cy="8" r="4" />
      <path d="M4.5 21a7.5 7.5 0 0 1 15 0" />
    </>
  ),
  wifi: <path d="M5 10a10 10 0 0 1 14 0M8 13a6 6 0 0 1 8 0m-5 4a1.5 1.5 0 1 1 2 0" />,
  zap: <path d="M13 2 5 14h7l-1 8 8-12h-7l1-8Z" />,
};

function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  return (
    <svg
      aria-hidden="true"
      fill="none"
      height={size}
      stroke="currentColor"
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="1.8"
      viewBox="0 0 24 24"
      width={size}
    >
      {paths[name]}
    </svg>
  );
}

type Trip = {
  id: number;
  depart: string;
  arrive: string;
  duration: string;
  type: string;
  price: number;
  seats: number;
};

const trips: Trip[] = [
  { id: 1, depart: "06:30", arrive: "12:15", duration: "5h 45m", type: "Volvo AC", price: 749, seats: 12 },
  { id: 2, depart: "09:15", arrive: "15:30", duration: "6h 15m", type: "AC Sleeper", price: 899, seats: 7 },
  { id: 3, depart: "22:00", arrive: "05:45", duration: "7h 45m", type: "Night Rider", price: 649, seats: 18 },
];

const seatRows = [
  ["1A", "1B", "1C", "1D"],
  ["2A", "2B", "2C", "2D"],
  ["3A", "3B", "3C", "3D"],
  ["4A", "4B", "4C", "4D"],
  ["5A", "5B", "5C", "5D"],
  ["6A", "6B", "6C", "6D"],
];
const occupied = new Set(["1C", "2A", "2B", "3D", "5C", "6A"]);

export default function App() {
  const [from, setFrom] = useState("Bengaluru");
  const [to, setTo] = useState("Chennai");
  const [date, setDate] = useState("2026-08-18");
  const [searched, setSearched] = useState(false);
  const [selectedTrip, setSelectedTrip] = useState<Trip | null>(null);
  const [selectedSeats, setSelectedSeats] = useState<string[]>([]);
  const [bookingStep, setBookingStep] = useState<"seats" | "passengers" | "payment" | "success">("seats");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [passengers, setPassengers] = useState([{ name: "", age: "", gender: "Female" }]);
  const [contact, setContact] = useState({ phone: "", email: "" });
  const [paymentMethod, setPaymentMethod] = useState<"upi" | "card" | "netbanking">("upi");
  const [upiId, setUpiId] = useState("");
  const [cancelPrompt, setCancelPrompt] = useState(false);
  const [tripCancelled, setTripCancelled] = useState(false);

  const dateLabel = useMemo(() => {
    const parsed = new Date(`${date}T12:00:00`);
    return parsed.toLocaleDateString("en-IN", { month: "short", day: "numeric", year: "numeric" });
  }, [date]);

  const swapRoute = () => {
    setFrom(to);
    setTo(from);
  };

  const toggleSeat = (seat: string) => {
    if (occupied.has(seat)) return;
    setSelectedSeats((current) =>
      current.includes(seat) ? current.filter((item) => item !== seat) : [...current, seat].slice(-4),
    );
  };

  const startBooking = (trip: Trip) => {
    setSelectedTrip(trip);
    setSelectedSeats([]);
    setBookingStep("seats");
    setPassengers([{ name: "", age: "", gender: "Female" }]);
    setContact({ phone: "", email: "" });
  };

  const continueToPassengers = () => {
    setPassengers(selectedSeats.map((_, index) => passengers[index] ?? { name: "", age: "", gender: "Female" }));
    setBookingStep("passengers");
  };

  const updatePassenger = (index: number, field: "name" | "age" | "gender", value: string) => {
    setPassengers((current) => current.map((passenger, passengerIndex) =>
      passengerIndex === index ? { ...passenger, [field]: value } : passenger,
    ));
  };

  return (
    <main className="app-shell">
      <header className="site-header">
        <div className="nav-wrap">
          <a className="brand" href="#top" aria-label="Roamly India home">
            <span className="brand-mark"><Icon name="bus" size={22} /></span>
            <span>roamly</span>
          </a>
          <nav className={mobileOpen ? "nav-links is-open" : "nav-links"} aria-label="Main navigation">
            <a className="active" href="#search">Book a trip</a>
            <a href="#my-trips">My trips</a>
            <a href="#help">Help</a>
          </nav>
          <div className="nav-actions">
            <button className="profile-button" type="button"><Icon name="user" size={18} /><span>Sign in</span></button>
            <button
              aria-label="Toggle menu"
              className="menu-button"
              onClick={() => setMobileOpen((current) => !current)}
              type="button"
            >
              <Icon name="menu" />
            </button>
          </div>
        </div>
      </header>

      <section className="hero" id="top">
        <div className="route-art route-art-one" />
        <div className="route-art route-art-two" />
        <div className="hero-content">
          <div className="eyebrow"><Icon name="spark" size={15} /> Travel across India with ease</div>
          <h1>Apni journey.<br /><em>Made simpler.</em></h1>
          <p>Comfortable, reliable bus travel connecting India’s cities — at prices that feel right.</p>

          <div className="search-card" id="search">
            <div className="trip-toggle">
              <button className="selected" type="button">One way</button>
              <button type="button">Round trip</button>
            </div>
            <div className="search-grid">
              <label className="field">
                <span className="field-label"><Icon name="location" size={16} /> From</span>
                <input value={from} onChange={(event) => setFrom(event.target.value)} />
              </label>
              <button className="swap-button" aria-label="Swap departure and destination" onClick={swapRoute} type="button">
                <Icon name="swap" size={18} />
              </button>
              <label className="field">
                <span className="field-label"><Icon name="location" size={16} /> To</span>
                <input value={to} onChange={(event) => setTo(event.target.value)} />
              </label>
              <label className="field date-field">
                <span className="field-label"><Icon name="calendar" size={16} /> Departure</span>
                <input type="date" value={date} onChange={(event) => setDate(event.target.value)} />
              </label>
              <button className="search-button" onClick={() => {
                setSearched(true);
                setTimeout(() => document.querySelector("#results")?.scrollIntoView({ behavior: "smooth" }), 30);
              }} type="button">
                <Icon name="search" size={19} /> Find a bus
              </button>
            </div>
          </div>

          <div className="trust-row">
            <span><Icon name="shield" size={17} /> Secure booking</span>
            <span><Icon name="zap" size={17} /> Instant confirmation</span>
            <span><Icon name="ticket" size={17} /> No hidden fees</span>
          </div>
        </div>
        <div className="scenic-card" aria-hidden="true">
          <div className="sun" />
          <div className="cloud cloud-one" />
          <div className="cloud cloud-two" />
          <div className="mountain mountain-back" />
          <div className="mountain mountain-front" />
          <div className="road">
            <div className="road-line" />
          </div>
          <div className="mini-bus"><span /><span /></div>
          <div className="scenic-caption"><Icon name="route" size={18} /><span><strong>2,500+ routes</strong> across India</span></div>
        </div>
      </section>

      <section className={searched ? "results visible" : "results"} id="results">
        <div className="section-heading">
          <div>
            <span className="kicker">Available departures</span>
            <h2>{from} <Icon name="arrow" size={26} /> {to}</h2>
            <p>{dateLabel} · 1 passenger</p>
          </div>
          <button className="modify-button" onClick={() => document.querySelector("#search")?.scrollIntoView({ behavior: "smooth" })} type="button">
            Modify search
          </button>
        </div>
        <div className="trip-list" id="trips">
          {trips.map((trip, index) => (
            <article className="trip-card" key={trip.id}>
              <div className="operator">
                <span className="operator-logo"><Icon name="bus" /></span>
                <div><strong>{index === 0 ? "KSRTC Airavat" : index === 1 ? "Orange Travels" : "Roamly Express"}</strong><span>{trip.type} · IN{104 + index}</span></div>
              </div>
              <div className="schedule">
                <div><strong>{trip.depart}</strong><span>{from}</span></div>
                <div className="journey-line"><span>{trip.duration}</span><i /><small>Direct</small></div>
                <div><strong>{trip.arrive}</strong><span>{to}</span></div>
              </div>
              <div className="amenities">
                <span title="Wi-Fi"><Icon name="wifi" size={18} /></span>
                <span title="Charging"><Icon name="zap" size={18} /></span>
                <span>{trip.seats} seats left</span>
              </div>
              <div className="fare">
                <span>from</span><strong>₹{trip.price}</strong>
                <button onClick={() => startBooking(trip)} type="button">Select <Icon name="arrow" size={16} /></button>
              </div>
            </article>
          ))}
        </div>
      </section>

      {!searched && (
        <section className="benefits">
          <div className="benefit-intro">
            <span className="kicker">Why Roamly India</span>
            <h2>Travel that feels<br />easy from the start.</h2>
          </div>
          <article><span><Icon name="ticket" /></span><h3>Fair prices, always</h3><p>Clear fares and flexible options, with no surprises at checkout.</p></article>
          <article><span><Icon name="shield" /></span><h3>Safe & dependable</h3><p>Trusted operators and verified routes for total peace of mind.</p></article>
          <article><span><Icon name="spark" /></span><h3>Comfort built in</h3><p>AC coaches, roomy seats, Wi-Fi and charging on selected routes.</p></article>
        </section>
      )}

      <section className="my-trips-section" id="my-trips">
        <div className="section-heading">
          <div>
            <span className="kicker">Manage booking</span>
            <h2>Your upcoming trip</h2>
            <p>View ticket details or cancel your journey.</p>
          </div>
        </div>
        <article className={tripCancelled ? "managed-trip cancelled" : "managed-trip"}>
          <div className="managed-status">
            <span className="operator-logo"><Icon name={tripCancelled ? "check" : "ticket"} /></span>
            <div><small>Booking ID</small><strong>RMY8K42P</strong></div>
          </div>
          <div className="managed-route">
            <div><strong>Hyderabad</strong><span>22:30 · 24 Aug</span></div>
            <div className="journey-line"><span>9h 15m</span><i /><small>{tripCancelled ? "Cancelled" : "Confirmed"}</small></div>
            <div><strong>Pune</strong><span>07:45 · 25 Aug</span></div>
          </div>
          <div className="managed-meta"><span>Orange Travels</span><strong>Seat L4</strong></div>
          {tripCancelled ? (
            <div className="refund-note"><strong>₹1,079 refund initiated</strong><span>Expected in 3–5 business days</span></div>
          ) : (
            <button className="cancel-trip-button" onClick={() => setCancelPrompt(true)} type="button">Cancel trip</button>
          )}
        </article>
      </section>

      {selectedTrip && (
        <div className="modal-backdrop" role="presentation" onMouseDown={() => setSelectedTrip(null)}>
          <section className="booking-modal" role="dialog" aria-modal="true" aria-label="Complete your booking" onMouseDown={(event) => event.stopPropagation()}>
            {bookingStep === "success" ? (
              <div className="success-state">
                <span className="success-icon"><Icon name="check" size={34} /></span>
                <span className="kicker">Payment successful</span>
                <h2>Shubh yatra!</h2>
                <p>Your ticket from {from} to {to} is confirmed. We’ve sent the e-ticket to {contact.phone || "your mobile"}.</p>
                <div className="confirmation-ticket">
                  <div><span>{dateLabel} · {selectedTrip.depart}</span><strong>{from}</strong></div>
                  <Icon name="arrow" />
                  <div><span>Seat {selectedSeats.join(", ")}</span><strong>{to}</strong></div>
                </div>
                <button className="confirm-button" onClick={() => setSelectedTrip(null)} type="button">Done</button>
              </div>
            ) : (
              <>
                <div className="modal-header">
                  <div>
                    <span className="kicker">Complete your booking</span>
                    <h2>{bookingStep === "seats" ? "Choose your seat" : bookingStep === "passengers" ? "Passenger details" : "Select payment"}</h2>
                    <p>{from} to {to} · {dateLabel} · {selectedTrip.depart}</p>
                  </div>
                  <button className="close-button" onClick={() => setSelectedTrip(null)} type="button" aria-label="Close">×</button>
                </div>
                <div className="checkout-progress">
                  {["Seats", "Passengers", "Payment"].map((step, index) => {
                    const currentIndex = bookingStep === "seats" ? 0 : bookingStep === "passengers" ? 1 : 2;
                    return <span className={index <= currentIndex ? "active" : ""} key={step}><i>{index < currentIndex ? "✓" : index + 1}</i>{step}</span>;
                  })}
                </div>

                {bookingStep === "seats" && (
                  <div className="booking-body">
                    <div className="seat-panel">
                      <div className="seat-key"><span><i className="available" /> Available</span><span><i className="seat-selected" /> Selected</span><span><i className="taken" /> Taken</span></div>
                      <div className="bus-layout">
                        <div className="driver">⌁</div>
                        {seatRows.map((row) => (
                          <div className="seat-row" key={row[0]}>
                            {row.map((seat, index) => (
                              <button
                                className={`${occupied.has(seat) ? "occupied" : ""} ${selectedSeats.includes(seat) ? "selected" : ""} ${index === 2 ? "aisle" : ""}`}
                                disabled={occupied.has(seat)}
                                key={seat}
                                onClick={() => toggleSeat(seat)}
                                type="button"
                              >
                                {seat}
                              </button>
                            ))}
                          </div>
                        ))}
                      </div>
                    </div>
                    <aside className="summary-panel">
                      <span className="kicker">Your journey</span>
                      <div className="summary-route">
                        <span><i />{from}<small>{selectedTrip.depart}</small></span>
                        <span><i />{to}<small>{selectedTrip.arrive}</small></span>
                      </div>
                      <div className="summary-line"><span>Date</span><strong>{dateLabel}</strong></div>
                      <div className="summary-line"><span>Seat{selectedSeats.length > 1 ? "s" : ""}</span><strong>{selectedSeats.length ? selectedSeats.join(", ") : "Choose a seat"}</strong></div>
                      <div className="total-line"><span>Fare</span><strong>₹{selectedTrip.price * Math.max(selectedSeats.length, 1)}</strong></div>
                      <button className="confirm-button" disabled={!selectedSeats.length} onClick={continueToPassengers} type="button">
                        Add passengers <Icon name="arrow" size={17} />
                      </button>
                      <small className="secure-note"><Icon name="shield" size={14} /> Free cancellation for 30 minutes</small>
                    </aside>
                  </div>
                )}

                {bookingStep === "passengers" && (
                  <div className="checkout-layout">
                    <div className="details-panel">
                      {selectedSeats.map((seat, index) => (
                        <fieldset className="passenger-card" key={seat}>
                          <legend>Passenger {index + 1} <span>Seat {seat}</span></legend>
                          <label className="form-field full"><span>Full name</span><input placeholder="As on government ID" value={passengers[index]?.name ?? ""} onChange={(event) => updatePassenger(index, "name", event.target.value)} /></label>
                          <label className="form-field"><span>Age</span><input inputMode="numeric" maxLength={3} placeholder="Age" value={passengers[index]?.age ?? ""} onChange={(event) => updatePassenger(index, "age", event.target.value.replace(/\D/g, ""))} /></label>
                          <label className="form-field"><span>Gender</span><select value={passengers[index]?.gender ?? "Female"} onChange={(event) => updatePassenger(index, "gender", event.target.value)}><option>Female</option><option>Male</option><option>Other</option></select></label>
                        </fieldset>
                      ))}
                      <fieldset className="passenger-card contact-card">
                        <legend>Contact details <span>Your ticket will be sent here</span></legend>
                        <label className="form-field"><span>Mobile number</span><div className="phone-input"><b>+91</b><input inputMode="tel" maxLength={10} placeholder="98765 43210" value={contact.phone} onChange={(event) => setContact({ ...contact, phone: event.target.value.replace(/\D/g, "") })} /></div></label>
                        <label className="form-field"><span>Email address</span><input type="email" placeholder="you@example.com" value={contact.email} onChange={(event) => setContact({ ...contact, email: event.target.value })} /></label>
                      </fieldset>
                    </div>
                    <aside className="mini-summary">
                      <span className="kicker">Fare summary</span>
                      <div className="summary-line"><span>Base fare × {selectedSeats.length}</span><strong>₹{selectedTrip.price * selectedSeats.length}</strong></div>
                      <div className="summary-line"><span>GST & fees</span><strong>₹0</strong></div>
                      <div className="total-line"><span>Total</span><strong>₹{selectedTrip.price * selectedSeats.length}</strong></div>
                      <button className="confirm-button" disabled={!passengers.every((passenger) => passenger.name && passenger.age) || contact.phone.length !== 10} onClick={() => setBookingStep("payment")} type="button">Continue to payment <Icon name="arrow" size={17} /></button>
                      <button className="back-button" onClick={() => setBookingStep("seats")} type="button">Back to seats</button>
                    </aside>
                  </div>
                )}

                {bookingStep === "payment" && (
                  <div className="checkout-layout">
                    <div className="details-panel payment-panel">
                      <button className={paymentMethod === "upi" ? "payment-option selected" : "payment-option"} onClick={() => setPaymentMethod("upi")} type="button"><span className="payment-logo upi">UPI</span><span><strong>UPI</strong><small>Pay with any UPI app</small></span><i /></button>
                      {paymentMethod === "upi" && <div className="payment-fields"><label className="form-field full"><span>UPI ID</span><div className="upi-input"><input placeholder="name@bank" value={upiId} onChange={(event) => setUpiId(event.target.value)} /><button type="button">Verify</button></div></label><div className="app-chips"><span>G Pay</span><span>PhonePe</span><span>Paytm</span><span>BHIM</span></div></div>}
                      <button className={paymentMethod === "card" ? "payment-option selected" : "payment-option"} onClick={() => setPaymentMethod("card")} type="button"><span className="payment-logo">CARD</span><span><strong>Credit or debit card</strong><small>Visa, Mastercard & RuPay</small></span><i /></button>
                      {paymentMethod === "card" && <div className="payment-fields card-fields"><label className="form-field full"><span>Card number</span><input inputMode="numeric" placeholder="1234 5678 9012 3456" /></label><label className="form-field"><span>Expiry</span><input placeholder="MM / YY" /></label><label className="form-field"><span>CVV</span><input inputMode="numeric" placeholder="•••" /></label></div>}
                      <button className={paymentMethod === "netbanking" ? "payment-option selected" : "payment-option"} onClick={() => setPaymentMethod("netbanking")} type="button"><span className="payment-logo">BANK</span><span><strong>Net banking</strong><small>All major Indian banks</small></span><i /></button>
                      {paymentMethod === "netbanking" && <div className="payment-fields bank-list"><button type="button">SBI</button><button type="button">HDFC</button><button type="button">ICICI</button><button type="button">Axis</button></div>}
                    </div>
                    <aside className="mini-summary">
                      <span className="kicker">Payment summary</span>
                      <div className="booking-mini-route"><strong>{from} → {to}</strong><span>{dateLabel} · {selectedSeats.join(", ")}</span></div>
                      <div className="total-line"><span>Amount payable</span><strong>₹{selectedTrip.price * selectedSeats.length}</strong></div>
                      <button className="confirm-button" disabled={paymentMethod === "upi" && !upiId.includes("@")} onClick={() => setBookingStep("success")} type="button">Pay ₹{selectedTrip.price * selectedSeats.length} securely</button>
                      <button className="back-button" onClick={() => setBookingStep("passengers")} type="button">Back to passenger details</button>
                      <small className="secure-note"><Icon name="shield" size={14} /> 100% secure payment</small>
                    </aside>
                  </div>
                )}
              </>
            )}
          </section>
        </div>
      )}

      {cancelPrompt && (
        <div className="modal-backdrop" role="presentation" onMouseDown={() => setCancelPrompt(false)}>
          <section className="cancel-modal" role="dialog" aria-modal="true" aria-label="Cancel trip" onMouseDown={(event) => event.stopPropagation()}>
            <span className="cancel-icon"><Icon name="ticket" size={27} /></span>
            <span className="kicker">Cancel booking</span>
            <h2>Cancel your Hyderabad trip?</h2>
            <p>As per the operator policy, a 10% cancellation fee will be deducted.</p>
            <div className="refund-breakdown"><span>Amount paid<strong>₹1,199</strong></span><span>Cancellation fee<strong>− ₹120</strong></span><span>Refund amount<strong>₹1,079</strong></span></div>
            <small>Refund will be sent to your original payment method in 3–5 business days.</small>
            <div className="cancel-actions"><button className="back-button" onClick={() => setCancelPrompt(false)} type="button">Keep my trip</button><button className="danger-button" onClick={() => { setTripCancelled(true); setCancelPrompt(false); }} type="button">Yes, cancel trip</button></div>
          </section>
        </div>
      )}

      <footer id="help">
        <a className="brand footer-brand" href="#top"><span className="brand-mark"><Icon name="bus" size={20} /></span><span>roamly</span></a>
        <p>Better journeys, one road at a time.</p>
        <span>© 2025 Roamly</span>
      </footer>
    </main>
  );
}
